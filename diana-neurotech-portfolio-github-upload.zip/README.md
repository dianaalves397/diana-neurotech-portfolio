# Diana Alves — Neurotech Portfolio

**Live:** https://diana-neurotech-portfolio.vercel.app

An editorial, interactive personal portfolio exploring biomedical technology, computational neuroscience, neural decoding and neurotechnology.

## Visual direction

The site takes cues from experimental editorial/web-design tools such as Readymag: oversized typography, asymmetric composition, motion, an interactive research map and a pointer-reactive neural field. It does **not** copy a specific Readymag template.

## Content integrity

The site intentionally distinguishes completed work from work in progress:

- **Movement Intention Decoder** — completed introductory project using synthetic neural-population data.
- **emg2mu bug analysis** — patch and regression test prepared locally; upstream PR not yet published.
- **NLB / real neural data** — explicitly labelled as the next planned step.

## Run locally

No build step or package install is required.

```bash
python3 -m http.server 3000
```

Then open `http://localhost:3000`.

## Deploy

The repository is ready for a zero-config Vercel deployment.

## Stack

- Semantic HTML
- CSS
- Vanilla JavaScript
- Canvas 2D for the neural field

## Accessibility

- Keyboard focus styles
- Native buttons and links
- Touch-safe research interactions
- `prefers-reduced-motion` support
- No essential interaction is hover-only
